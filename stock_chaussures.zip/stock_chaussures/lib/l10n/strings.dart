import 'package:flutter/widgets.dart';

/// Traductions de l'application.
///
/// Usage dans un widget :
/// ```dart
/// final t = L.of(context).t;
/// Text(t('my_stock'));
/// Text(t('stock_after', {'n': 4}));
/// ```
///
/// Pour ajouter une langue : créez une table `_it`, `_en`… et complétez
/// [tableFor] + [supportedLocales].
class L {
  const L(this.code);

  final String code;

  static const List<Locale> supportedLocales = [Locale('fr'), Locale('es')];

  static L of(BuildContext context) =>
      L(Localizations.localeOf(context).languageCode);

  static Map<String, String> tableFor(String code) => code == 'es' ? _es : _fr;

  /// Traduit une clé et remplace les jetons `{nom}` par les valeurs fournies.
  String t(String key, [Map<String, Object>? args]) {
    var value = tableFor(code)[key] ?? _fr[key] ?? key;
    if (args != null) {
      args.forEach((name, arg) => value = value.replaceAll('{$name}', '$arg'));
    }
    return value;
  }

  /// Pluriel simple : `plural(1, 'reference')` → clé `reference_one`.
  String plural(int count, String baseKey, [Map<String, Object>? args]) {
    final key = count == 1 ? '${baseKey}_one' : '${baseKey}_other';
    return t(key, {'n': count, ...?args});
  }
}

const Map<String, String> _fr = {
  // Général
  'app_title': 'Stock Chaussures',
  'tab_stock': 'Stock',
  'tab_movements': 'Mouvements',
  'tab_stats': 'Statistiques',
  'add': 'Ajouter',
  'cancel': 'Annuler',
  'delete': 'Supprimer',
  'validate': 'Valider',
  'close': 'Fermer',
  'settings': 'Paramètres',
  'language': 'Langue',
  'language_fr': 'Français',
  'language_es': 'Espagnol',
  'language_changed': 'Langue modifiée',
  'about': 'À propos',
  'about_offline': 'Toutes vos données restent sur cet appareil. '
      'Aucune connexion internet n\'est nécessaire.',

  // Stock
  'my_stock': 'Mon stock',
  'search_hint': 'Marque, modèle, couleur, pointure…',
  'clear_search': 'Effacer la recherche',
  'filter_sort': 'Filtrer et trier',
  'total_stock_value': 'Valeur totale du stock',
  'selection_shown': 'Sélection affichée',
  'immobilized_value': 'Valeur d\'achat immobilisée',
  'potential_sale': 'Vente potentielle',
  'profit': 'Bénéfice',
  'refs_pairs': '{refs} réf. · {items} paires',
  'reference_one': '{n} référence',
  'reference_other': '{n} références',
  'clear_all': 'Tout effacer',
  'no_results_title': 'Aucun résultat',
  'no_results_msg': 'Aucune chaussure ne correspond à cette recherche. '
      'Modifiez les filtres pour élargir la sélection.',
  'reset': 'Réinitialiser',
  'empty_stock_title': 'Votre stock est vide',
  'empty_stock_msg': 'Ajoutez votre première paire : photo, pointure, '
      'prix d\'achat et de vente.',
  'add_shoe': 'Ajouter une chaussure',
  'size_short': 'P. {n}',
  'size_full': 'pointure {n}',
  'in_stock_n': '{n} en stock',
  'remaining_n': '{n} restantes',
  'out_of_stock': 'Rupture',
  'low_stock': 'Stock faible',

  // Filtres
  'filter_title': 'Filtrer le stock',
  'sort_by': 'Trier par',
  'brand': 'Marque',
  'color': 'Couleur',
  'size': 'Pointure',
  'availability': 'Disponibilité',
  'low_stock_switch': 'Stock faible ou rupture',
  'low_stock_desc': '{n} paires restantes ou moins',
  'apply_filters_one': 'Appliquer {n} filtre',
  'apply_filters_other': 'Appliquer {n} filtres',
  'see_stock': 'Voir le stock',
  'sort_recent': 'Modifiés récemment',
  'sort_brand': 'Marque (A → Z)',
  'sort_qty_desc': 'Quantité (décroissante)',
  'sort_qty_asc': 'Quantité (croissante)',
  'sort_value': 'Valeur du stock',
  'sort_profit': 'Bénéfice potentiel',

  // Fiche produit
  'new_shoe': 'Nouvelle chaussure',
  'edit_sheet': 'Modifier la fiche',
  'identification': 'Identification',
  'model': 'Modèle',
  'quantity': 'Quantité',
  'prices': 'Prix',
  'purchase_price': 'Prix d\'achat',
  'sale_price': 'Prix de vente',
  'unit_purchase_price': 'Prix d\'achat unitaire',
  'unit_sale_price': 'Prix de vente unitaire',
  'unit_margin': 'Marge unitaire',
  'stock_value': 'Valeur du stock (achat)',
  'potential_profit': 'Bénéfice potentiel',
  'note': 'Note',
  'note_optional': 'Note (facultatif)',
  'note_hint': 'Emplacement, fournisseur, état de la boîte…',
  'add_to_stock': 'Ajouter au stock',
  'save_changes': 'Enregistrer les modifications',
  'shoe_added': 'Chaussure ajoutée au stock',
  'sheet_updated': 'Fiche mise à jour',
  'initial_stock': 'Stock initial',
  'initial_stock_hint': 'Enregistré comme une entrée de stock tracée.',
  'quantity_locked': 'Quantité gérée par les mouvements',
  'quantity_locked_hint': 'Déclarez une entrée ou une sortie pour la modifier.',
  'brand_hint': 'Nike, Adidas, New Balance…',
  'model_hint': 'Air Max 90, Stan Smith…',
  'color_hint': 'Noir, blanc, rouge…',
  'added_modified': 'Ajoutée le {added} · modifiée le {updated}',
  'delete_confirm_title': 'Supprimer cette référence ?',
  'delete_confirm_msg': '{name} ({size}) sera retirée du stock avec tout son '
      'historique de mouvements. Cette action est définitive.',
  'deleted': '{name} supprimée',

  // Photo
  'add_photo': 'Ajouter une photo',
  'change_photo': 'Changer la photo',
  'take_photo': 'Prendre une photo',
  'choose_gallery': 'Choisir dans la galerie',
  'remove_photo': 'Retirer la photo',
  'camera_error': 'Impossible d\'ouvrir l\'appareil photo. '
      'Vérifiez l\'autorisation Caméra dans les réglages.',
  'gallery_error': 'Impossible d\'ouvrir la galerie. '
      'Vérifiez les autorisations dans les réglages.',

  // Validation
  'required': 'Ce champ est obligatoire.',
  'invalid_size': 'Pointure invalide (ex. 42 ou 42,5).',
  'size_range': 'Pointure hors plage (1 à 70).',
  'invalid_amount': 'Montant invalide (ex. 89,90).',
  'invalid_integer': 'Indiquez un nombre entier.',
  'no_negative': 'La valeur ne peut pas être négative.',
  'min_one': 'Indiquez au moins 1.',

  // Mouvements
  'movement_entry': 'Entrée',
  'movement_exit': 'Sortie',
  'declare_entry': 'Déclarer une entrée',
  'declare_exit': 'Déclarer une sortie',
  'entry_short': 'Entrée',
  'exit_short': 'Sortie',
  'reason': 'Motif',
  'reason_purchase': 'Achat',
  'reason_restock': 'Réassort',
  'reason_customer_return': 'Retour client',
  'reason_initial': 'Stock initial',
  'reason_inventory_plus': 'Correction d\'inventaire (+)',
  'reason_sale': 'Vente',
  'reason_supplier_return': 'Retour fournisseur',
  'reason_loss': 'Perte ou vol',
  'reason_damage': 'Casse',
  'reason_inventory_minus': 'Correction d\'inventaire (−)',
  'unit_price': 'Prix unitaire',
  'total': 'Total',
  'movement_note_hint': 'Client, fournisseur, n° de commande…',
  'quantity_remaining': 'Quantité restante',
  'movement_hint': 'Vente, réassort, perte : chaque mouvement est tracé.',
  'stock_after': 'Stock après : {n}',
  'insufficient_stock': 'Stock insuffisant : {n} en stock seulement.',
  'max_quantity': 'Maximum {n}',
  'entry_saved': 'Entrée enregistrée',
  'exit_saved': 'Sortie enregistrée',
  'history': 'Historique',
  'movement_history': 'Historique des mouvements',
  'recent_movements': 'Derniers mouvements',
  'see_all_history': 'Tout l\'historique',
  'no_movements_title': 'Aucun mouvement',
  'no_movements_msg': 'Les entrées et sorties de stock apparaîtront ici, '
      'avec leur motif et leur date.',
  'movements_all': 'Tous',
  'movements_entries': 'Entrées',
  'movements_exits': 'Sorties',
  'today': 'Aujourd\'hui',
  'yesterday': 'Hier',
  'sold_units': 'Paires vendues',
  'revenue': 'CA réalisé',
  'realized_profit': 'Bénéfice réalisé',
  'sales_summary': 'Ventes enregistrées',

  'recalculate_stock': 'Vérifier les quantités',
  'recalculate_stock_desc': 'Recalcule chaque stock depuis le journal des mouvements.',
  'recalculate_ok': 'Tous les stocks sont cohérents',
  'recalculate_fixed': '{n} référence(s) corrigée(s)',

  // Statistiques
  'references': 'Références',
  'pairs_in_stock': 'Paires en stock',
  'out_of_stock_count': 'En rupture',
  'brands_breakdown': 'Répartition par marque',
  'to_restock': 'À réapprovisionner',
  'brand_line': '{items} paires · {refs} réf. · bénéfice {profit}',
  'stats_empty_title': 'Pas encore de statistiques',
  'stats_empty_msg': 'Ajoutez des chaussures pour suivre la valeur de votre '
      'stock et votre bénéfice potentiel.',
};

const Map<String, String> _es = {
  // General
  'app_title': 'Stock de Zapatos',
  'tab_stock': 'Stock',
  'tab_movements': 'Movimientos',
  'tab_stats': 'Estadísticas',
  'add': 'Añadir',
  'cancel': 'Cancelar',
  'delete': 'Eliminar',
  'validate': 'Validar',
  'close': 'Cerrar',
  'settings': 'Ajustes',
  'language': 'Idioma',
  'language_fr': 'Francés',
  'language_es': 'Español',
  'language_changed': 'Idioma actualizado',
  'about': 'Acerca de',
  'about_offline': 'Todos tus datos permanecen en este dispositivo. '
      'No se necesita conexión a internet.',

  // Stock
  'my_stock': 'Mi stock',
  'search_hint': 'Marca, modelo, color, talla…',
  'clear_search': 'Borrar la búsqueda',
  'filter_sort': 'Filtrar y ordenar',
  'total_stock_value': 'Valor total del stock',
  'selection_shown': 'Selección mostrada',
  'immobilized_value': 'Valor de compra inmovilizado',
  'potential_sale': 'Venta potencial',
  'profit': 'Beneficio',
  'refs_pairs': '{refs} ref. · {items} pares',
  'reference_one': '{n} referencia',
  'reference_other': '{n} referencias',
  'clear_all': 'Borrar todo',
  'no_results_title': 'Sin resultados',
  'no_results_msg': 'Ningún zapato coincide con esta búsqueda. '
      'Modifica los filtros para ampliar la selección.',
  'reset': 'Restablecer',
  'empty_stock_title': 'Tu stock está vacío',
  'empty_stock_msg': 'Añade tu primer par: foto, talla, '
      'precio de compra y de venta.',
  'add_shoe': 'Añadir un zapato',
  'size_short': 'T. {n}',
  'size_full': 'talla {n}',
  'in_stock_n': '{n} en stock',
  'remaining_n': '{n} restantes',
  'out_of_stock': 'Agotado',
  'low_stock': 'Stock bajo',

  // Filtros
  'filter_title': 'Filtrar el stock',
  'sort_by': 'Ordenar por',
  'brand': 'Marca',
  'color': 'Color',
  'size': 'Talla',
  'availability': 'Disponibilidad',
  'low_stock_switch': 'Stock bajo o agotado',
  'low_stock_desc': '{n} pares restantes o menos',
  'apply_filters_one': 'Aplicar {n} filtro',
  'apply_filters_other': 'Aplicar {n} filtros',
  'see_stock': 'Ver el stock',
  'sort_recent': 'Modificados recientemente',
  'sort_brand': 'Marca (A → Z)',
  'sort_qty_desc': 'Cantidad (descendente)',
  'sort_qty_asc': 'Cantidad (ascendente)',
  'sort_value': 'Valor del stock',
  'sort_profit': 'Beneficio potencial',

  // Ficha
  'new_shoe': 'Nuevo zapato',
  'edit_sheet': 'Editar la ficha',
  'identification': 'Identificación',
  'model': 'Modelo',
  'quantity': 'Cantidad',
  'prices': 'Precios',
  'purchase_price': 'Precio de compra',
  'sale_price': 'Precio de venta',
  'unit_purchase_price': 'Precio de compra unitario',
  'unit_sale_price': 'Precio de venta unitario',
  'unit_margin': 'Margen unitario',
  'stock_value': 'Valor del stock (compra)',
  'potential_profit': 'Beneficio potencial',
  'note': 'Nota',
  'note_optional': 'Nota (opcional)',
  'note_hint': 'Ubicación, proveedor, estado de la caja…',
  'add_to_stock': 'Añadir al stock',
  'save_changes': 'Guardar los cambios',
  'shoe_added': 'Zapato añadido al stock',
  'sheet_updated': 'Ficha actualizada',
  'initial_stock': 'Stock inicial',
  'initial_stock_hint': 'Se registra como una entrada de stock trazada.',
  'quantity_locked': 'Cantidad gestionada por los movimientos',
  'quantity_locked_hint': 'Declara una entrada o una salida para modificarla.',
  'brand_hint': 'Nike, Adidas, New Balance…',
  'model_hint': 'Air Max 90, Stan Smith…',
  'color_hint': 'Negro, blanco, rojo…',
  'added_modified': 'Añadido el {added} · modificado el {updated}',
  'delete_confirm_title': '¿Eliminar esta referencia?',
  'delete_confirm_msg': '{name} ({size}) se retirará del stock junto con todo '
      'su historial de movimientos. Esta acción es definitiva.',
  'deleted': '{name} eliminado',

  // Foto
  'add_photo': 'Añadir una foto',
  'change_photo': 'Cambiar la foto',
  'take_photo': 'Hacer una foto',
  'choose_gallery': 'Elegir de la galería',
  'remove_photo': 'Quitar la foto',
  'camera_error': 'No se puede abrir la cámara. '
      'Comprueba el permiso de Cámara en los ajustes.',
  'gallery_error': 'No se puede abrir la galería. '
      'Comprueba los permisos en los ajustes.',

  // Validación
  'required': 'Este campo es obligatorio.',
  'invalid_size': 'Talla no válida (ej. 42 o 42,5).',
  'size_range': 'Talla fuera de rango (1 a 70).',
  'invalid_amount': 'Importe no válido (ej. 89,90).',
  'invalid_integer': 'Indica un número entero.',
  'no_negative': 'El valor no puede ser negativo.',
  'min_one': 'Indica al menos 1.',

  // Movimientos
  'movement_entry': 'Entrada',
  'movement_exit': 'Salida',
  'declare_entry': 'Declarar una entrada',
  'declare_exit': 'Declarar una salida',
  'entry_short': 'Entrada',
  'exit_short': 'Salida',
  'reason': 'Motivo',
  'reason_purchase': 'Compra',
  'reason_restock': 'Reposición',
  'reason_customer_return': 'Devolución de cliente',
  'reason_initial': 'Stock inicial',
  'reason_inventory_plus': 'Ajuste de inventario (+)',
  'reason_sale': 'Venta',
  'reason_supplier_return': 'Devolución a proveedor',
  'reason_loss': 'Pérdida o robo',
  'reason_damage': 'Rotura',
  'reason_inventory_minus': 'Ajuste de inventario (−)',
  'unit_price': 'Precio unitario',
  'total': 'Total',
  'movement_note_hint': 'Cliente, proveedor, n.º de pedido…',
  'quantity_remaining': 'Cantidad restante',
  'movement_hint': 'Venta, reposición, pérdida: cada movimiento queda trazado.',
  'stock_after': 'Stock después: {n}',
  'insufficient_stock': 'Stock insuficiente: solo {n} en stock.',
  'max_quantity': 'Máximo {n}',
  'entry_saved': 'Entrada registrada',
  'exit_saved': 'Salida registrada',
  'history': 'Historial',
  'movement_history': 'Historial de movimientos',
  'recent_movements': 'Últimos movimientos',
  'see_all_history': 'Todo el historial',
  'no_movements_title': 'Ningún movimiento',
  'no_movements_msg': 'Las entradas y salidas de stock aparecerán aquí, '
      'con su motivo y su fecha.',
  'movements_all': 'Todos',
  'movements_entries': 'Entradas',
  'movements_exits': 'Salidas',
  'today': 'Hoy',
  'yesterday': 'Ayer',
  'sold_units': 'Pares vendidos',
  'revenue': 'Ingresos realizados',
  'realized_profit': 'Beneficio realizado',
  'sales_summary': 'Ventas registradas',

  'recalculate_stock': 'Verificar las cantidades',
  'recalculate_stock_desc': 'Recalcula cada stock a partir del historial de movimientos.',
  'recalculate_ok': 'Todos los stocks son coherentes',
  'recalculate_fixed': '{n} referencia(s) corregida(s)',

  // Estadísticas
  'references': 'Referencias',
  'pairs_in_stock': 'Pares en stock',
  'out_of_stock_count': 'Agotados',
  'brands_breakdown': 'Reparto por marca',
  'to_restock': 'Para reponer',
  'brand_line': '{items} pares · {refs} ref. · beneficio {profit}',
  'stats_empty_title': 'Todavía no hay estadísticas',
  'stats_empty_msg': 'Añade zapatos para seguir el valor de tu stock '
      'y tu beneficio potencial.',
};
