import 'package:intl/intl.dart';

import 'constants.dart';

/// Formatage centralisé : montants, pointures, dates.
/// La locale suit la langue choisie dans les réglages ([setLanguage]).
class Fmt {
  Fmt._();

  static String _locale = 'fr_FR';

  static NumberFormat _money = _buildMoney('fr_FR');
  static NumberFormat _moneyCompact = _buildMoneyCompact('fr_FR');
  static NumberFormat _int = NumberFormat.decimalPattern('fr_FR');

  static NumberFormat _buildMoney(String locale) => NumberFormat.currency(
        locale: locale,
        symbol: kCurrencySymbol,
        decimalDigits: 2,
      );

  static NumberFormat _buildMoneyCompact(String locale) =>
      NumberFormat.compactCurrency(
        locale: locale,
        symbol: kCurrencySymbol,
        decimalDigits: 1,
      );

  /// Appelée au démarrage puis à chaque changement de langue.
  static void setLanguage(String languageCode) {
    _locale = languageCode == 'es' ? 'es_ES' : 'fr_FR';
    _money = _buildMoney(_locale);
    _moneyCompact = _buildMoneyCompact(_locale);
    _int = NumberFormat.decimalPattern(_locale);
  }

  static String money(num value) => _money.format(value);

  static String moneyShort(num value) =>
      value.abs() >= 10000 ? _moneyCompact.format(value) : _money.format(value);

  static String number(num value) => _int.format(value);

  /// Montant signé, pour les mouvements : « +89,90 € ».
  static String signedMoney(num value) =>
      value > 0 ? '+${money(value)}' : money(value);

  /// 42.0 -> « 42 » ; 42.5 -> « 42,5 »
  static String size(double value) {
    if (value == value.roundToDouble()) return value.toStringAsFixed(0);
    return value.toStringAsFixed(1).replaceAll('.', ',');
  }

  static String percent(double value) {
    final sign = value > 0 ? '+' : '';
    return '$sign${value.toStringAsFixed(1).replaceAll('.', ',')} %';
  }

  static String date(DateTime value) =>
      DateFormat('d MMMM y', _locale).format(value);

  static String dayMonth(DateTime value) =>
      DateFormat('EEEE d MMMM', _locale).format(value);

  static String time(DateTime value) => DateFormat.Hm(_locale).format(value);

  /// Convertit une saisie utilisateur (« 12,90 ») en double.
  static double? parseNumber(String? input) {
    if (input == null) return null;
    final cleaned = input.trim().replaceAll(' ', '').replaceAll(',', '.');
    if (cleaned.isEmpty) return null;
    return double.tryParse(cleaned);
  }

  /// Vrai si les deux dates tombent le même jour.
  static bool sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}
