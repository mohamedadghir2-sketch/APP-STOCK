import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../l10n/strings.dart';
import '../models/shoe.dart';
import '../models/stock_movement.dart';
import '../providers/shoe_provider.dart';
import '../utils/constants.dart';
import '../utils/formatters.dart';

/// Ouvre la feuille de déclaration d'un mouvement.
/// Renvoie `true` si un mouvement a été enregistré.
Future<bool?> showMovementSheet(
  BuildContext context, {
  required Shoe shoe,
  required MovementType type,
}) {
  return showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Theme.of(context).colorScheme.surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
    ),
    builder: (_) => MovementSheet(shoe: shoe, type: type),
  );
}

class MovementSheet extends StatefulWidget {
  const MovementSheet({super.key, required this.shoe, required this.type});

  final Shoe shoe;
  final MovementType type;

  @override
  State<MovementSheet> createState() => _MovementSheetState();
}

class _MovementSheetState extends State<MovementSheet> {
  late final List<MovementReason> _reasons = MovementReason.forType(widget.type)
      .where((reason) => reason != MovementReason.initialStock)
      .toList();

  late MovementReason _reason = _reasons.first;
  late final TextEditingController _quantity = TextEditingController(text: '1');
  late final TextEditingController _price = TextEditingController(
    text: (isEntry ? widget.shoe.purchasePrice : widget.shoe.salePrice)
        .toStringAsFixed(2),
  );
  final TextEditingController _note = TextEditingController();

  String? _error;
  bool _saving = false;

  bool get isEntry => widget.type == MovementType.entry;
  Color get accent => isEntry ? StockColors.ok : StockColors.low;

  int get _quantityValue => int.tryParse(_quantity.text.trim()) ?? 0;

  @override
  void initState() {
    super.initState();
    _quantity.addListener(() => setState(() {}));
    _price.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _quantity.dispose();
    _price.dispose();
    _note.dispose();
    super.dispose();
  }

  void _bump(int delta) {
    final next = (_quantityValue + delta).clamp(1, 99999);
    _quantity.text = '$next';
  }

  Future<void> _submit() async {
    final t = L.of(context).t;
    final quantity = _quantityValue;
    if (quantity < 1) {
      setState(() => _error = t('min_one'));
      return;
    }
    if (!isEntry && quantity > widget.shoe.quantity) {
      setState(() =>
          _error = t('insufficient_stock', {'n': widget.shoe.quantity}));
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    try {
      await context.read<ShoeProvider>().recordMovement(
            shoeId: widget.shoe.id!,
            type: widget.type,
            reason: _reason,
            quantity: quantity,
            unitPrice: Fmt.parseNumber(_price.text),
            note: _note.text,
          );
      navigator.pop(true);
      messenger
        ..clearSnackBars()
        ..showSnackBar(SnackBar(
          content: Text(isEntry ? t('entry_saved') : t('exit_saved')),
        ));
    } on InsufficientStockException catch (error) {
      if (mounted) {
        setState(() {
          _saving = false;
          _error = t('insufficient_stock', {'n': error.available});
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = L.of(context).t;
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final quantity = _quantityValue;
    final unitPrice = Fmt.parseNumber(_price.text) ?? 0;
    final after = isEntry
        ? widget.shoe.quantity + quantity
        : widget.shoe.quantity - quantity;

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // En-tête
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.14),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      isEntry
                          ? Icons.south_west_rounded
                          : Icons.north_east_rounded,
                      color: accent,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isEntry ? t('declare_entry') : t('declare_exit'),
                          style: theme.textTheme.titleLarge
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        Text(
                          '${widget.shoe.title} · '
                          '${t('size_short', {'n': Fmt.size(widget.shoe.size)})}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodySmall
                              ?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 22),

              // Quantité
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(t('quantity'),
                            style: theme.textTheme.titleSmall
                                ?.copyWith(fontWeight: FontWeight.w700)),
                        Text(
                          isEntry
                              ? t('in_stock_n', {'n': widget.shoe.quantity})
                              : t('max_quantity', {'n': widget.shoe.quantity}),
                          style: theme.textTheme.bodySmall
                              ?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: () => _bump(-1),
                    icon: const Icon(Icons.remove_rounded),
                  ),
                  SizedBox(
                    width: 64,
                    child: TextField(
                      controller: _quantity,
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: const InputDecoration(
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 4, vertical: 12),
                      ),
                      style: theme.textTheme.titleLarge
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: () => _bump(1),
                    icon: const Icon(Icons.add_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Motif
              Text(t('reason').toUpperCase(),
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.3,
                    color: scheme.onSurfaceVariant,
                  )),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final reason in _reasons)
                    ChoiceChip(
                      label: Text(t(reason.key)),
                      selected: _reason == reason,
                      onSelected: (_) => setState(() => _reason = reason),
                    ),
                ],
              ),
              const SizedBox(height: 20),

              // Prix unitaire
              TextField(
                controller: _price,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
                ],
                decoration: InputDecoration(
                  labelText: t('unit_price'),
                  suffixText: kCurrencySymbol,
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _note,
                decoration: InputDecoration(
                  labelText: t('note_optional'),
                  hintText: t('movement_note_hint'),
                ),
                textCapitalization: TextCapitalization.sentences,
              ),
              const SizedBox(height: 18),

              // Récapitulatif
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accent.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(t('total'))),
                        Text(
                          Fmt.money(unitPrice * quantity),
                          style: theme.textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            t('stock_after', {'n': after < 0 ? 0 : after}),
                            style: TextStyle(color: scheme.onSurfaceVariant),
                          ),
                        ),
                        Text(
                          '${isEntry ? '+' : '−'}$quantity',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            color: accent,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              if (_error != null) ...[
                const SizedBox(height: 14),
                Row(
                  children: [
                    const Icon(Icons.error_outline_rounded,
                        color: StockColors.out, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _error!,
                        style: const TextStyle(
                            color: StockColors.out, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ],

              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _saving ? null : _submit,
                  style: FilledButton.styleFrom(backgroundColor: accent),
                  child: _saving
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                              strokeWidth: 2.4, color: Colors.white),
                        )
                      : Text(t('validate')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
