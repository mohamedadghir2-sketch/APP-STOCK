import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../models/stock_movement.dart';
import '../utils/constants.dart';
import '../utils/formatters.dart';

/// Une ligne du journal : motif, date, quantité signée et stock résultant.
class MovementTile extends StatelessWidget {
  const MovementTile({
    super.key,
    required this.movement,
    this.showShoe = false,
    this.onTap,
  });

  final StockMovement movement;

  /// Affiche la chaussure concernée (historique global).
  final bool showShoe;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final t = L.of(context).t;
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final isEntry = movement.isEntry;
    final accent = isEntry ? StockColors.ok : StockColors.low;

    final details = <String>[
      if (showShoe) t(movement.reason.key),
      if (showShoe && movement.shoeSize != null)
        t('size_short', {'n': Fmt.size(movement.shoeSize!)}),
      Fmt.time(movement.createdAt),
      if (movement.unitPrice != null && movement.unitPrice! > 0)
        Fmt.money(movement.total),
    ];

    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: accent.withOpacity(0.14),
          shape: BoxShape.circle,
        ),
        child: Icon(
          isEntry ? Icons.south_west_rounded : Icons.north_east_rounded,
          size: 19,
          color: accent,
        ),
      ),
      title: Text(
        showShoe ? movement.shoeLabel : t(movement.reason.key),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: theme.textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w700),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            details.join(' · '),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.bodySmall
                ?.copyWith(color: scheme.onSurfaceVariant),
          ),
          if ((movement.note ?? '').isNotEmpty)
            Text(
              movement.note!,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall?.copyWith(
                color: scheme.onSurfaceVariant,
                fontStyle: FontStyle.italic,
              ),
            ),
        ],
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            '${isEntry ? '+' : '−'}${movement.quantity}',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w800,
              color: accent,
            ),
          ),
          Text(
            '→ ${movement.quantityAfter}',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

/// En-tête de groupe par journée dans l'historique.
class MovementDayHeader extends StatelessWidget {
  const MovementDayHeader({super.key, required this.date});

  final DateTime date;

  @override
  Widget build(BuildContext context) {
    final t = L.of(context).t;
    final now = DateTime.now();
    final label = Fmt.sameDay(date, now)
        ? t('today')
        : Fmt.sameDay(date, now.subtract(const Duration(days: 1)))
            ? t('yesterday')
            : Fmt.dayMonth(date);

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 6),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.3,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}
