import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import 'movements_view.dart';
import 'shoe_form_screen.dart';
import 'stats_view.dart';
import 'stock_view.dart';

/// Coquille de l'application : Stock / Mouvements / Statistiques.
class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _index = 0;

  Future<void> _addShoe() async {
    final t = L.of(context).t;
    final created = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const ShoeFormScreen()),
    );
    if (created == true && mounted) {
      ScaffoldMessenger.of(context)
        ..clearSnackBars()
        ..showSnackBar(SnackBar(content: Text(t('shoe_added'))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = L.of(context).t;

    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [StockView(), MovementsView(), StatsView()],
      ),
      floatingActionButton: _index == 0
          ? FloatingActionButton.extended(
              onPressed: _addShoe,
              icon: const Icon(Icons.add_rounded),
              label: Text(t('add')),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.inventory_2_outlined),
            selectedIcon: const Icon(Icons.inventory_2),
            label: t('tab_stock'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.swap_vert_rounded),
            selectedIcon: const Icon(Icons.swap_vert_circle),
            label: t('tab_movements'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.insights_outlined),
            selectedIcon: const Icon(Icons.insights),
            label: t('tab_stats'),
          ),
        ],
      ),
    );
  }
}
