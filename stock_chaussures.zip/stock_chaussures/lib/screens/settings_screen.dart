import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/strings.dart';
import '../providers/settings_provider.dart';
import '../providers/shoe_provider.dart';
import '../theme/app_theme.dart';

/// Réglages : langue de l'interface et outils de vérification du stock.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = L.of(context).t;
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final settings = context.watch<SettingsProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(t('settings'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          _Title(t('language')),
          Container(
            decoration: AppTheme.cardDecoration(context),
            clipBehavior: Clip.antiAlias,
            child: Column(
              children: [
                _LanguageTile(
                  code: 'fr',
                  label: t('language_fr'),
                  flag: '🇫🇷',
                  selected: settings.language == 'fr',
                ),
                const Divider(height: 1),
                _LanguageTile(
                  code: 'es',
                  label: t('language_es'),
                  flag: '🇪🇸',
                  selected: settings.language == 'es',
                ),
              ],
            ),
          ),

          const SizedBox(height: 26),
          _Title(t('history')),
          Container(
            decoration: AppTheme.cardDecoration(context),
            clipBehavior: Clip.antiAlias,
            child: ListTile(
              leading: const Icon(Icons.calculate_outlined),
              title: Text(t('recalculate_stock')),
              subtitle: Text(
                t('recalculate_stock_desc'),
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: scheme.onSurfaceVariant),
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () async {
                final messenger = ScaffoldMessenger.of(context);
                final fixed =
                    await context.read<ShoeProvider>().recalculateQuantities();
                messenger
                  ..clearSnackBars()
                  ..showSnackBar(SnackBar(
                    content: Text(fixed == 0
                        ? t('recalculate_ok')
                        : t('recalculate_fixed', {'n': fixed})),
                  ));
              },
            ),
          ),

          const SizedBox(height: 26),
          _Title(t('about')),
          Container(
            width: double.infinity,
            decoration: AppTheme.cardDecoration(context),
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                Icon(Icons.offline_bolt_outlined,
                    color: scheme.onSurfaceVariant),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    t('about_offline'),
                    style: theme.textTheme.bodyMedium
                        ?.copyWith(color: scheme.onSurfaceVariant),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LanguageTile extends StatelessWidget {
  const _LanguageTile({
    required this.code,
    required this.label,
    required this.flag,
    required this.selected,
  });

  final String code;
  final String label;
  final String flag;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final t = L.of(context).t;
    final scheme = Theme.of(context).colorScheme;

    return ListTile(
      leading: Text(flag, style: const TextStyle(fontSize: 24)),
      title: Text(
        label,
        style: TextStyle(fontWeight: selected ? FontWeight.w700 : FontWeight.w500),
      ),
      trailing: selected
          ? Icon(Icons.check_circle_rounded, color: scheme.primary)
          : const Icon(Icons.radio_button_unchecked_rounded),
      onTap: selected
          ? null
          : () async {
              final messenger = ScaffoldMessenger.of(context);
              await context.read<SettingsProvider>().setLanguage(code);
              messenger
                ..clearSnackBars()
                ..showSnackBar(
                  SnackBar(content: Text(t('language_changed'))),
                );
            },
    );
  }
}

class _Title extends StatelessWidget {
  const _Title(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, left: 4),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.3,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}
