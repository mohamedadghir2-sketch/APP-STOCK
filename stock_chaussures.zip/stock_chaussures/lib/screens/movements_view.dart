import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/strings.dart';
import '../models/stock_movement.dart';
import '../providers/shoe_provider.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../utils/formatters.dart';
import '../widgets/empty_state.dart';
import '../widgets/movement_tile.dart';
import 'settings_screen.dart';
import 'shoe_detail_screen.dart';

/// Onglet « Mouvements » : journal complet des entrées et sorties.
class MovementsView extends StatefulWidget {
  const MovementsView({super.key});

  @override
  State<MovementsView> createState() => _MovementsViewState();
}

class _MovementsViewState extends State<MovementsView> {
  Future<void> _openShoe(int shoeId) async {
    final shoe = await context.read<ShoeProvider>().byId(shoeId);
    if (shoe == null || !mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ShoeDetailScreen(shoe: shoe)),
    );
  }

  /// Aplatit la liste en alternant en-têtes de journée et mouvements.
  List<Object> _entries(List<StockMovement> movements) {
    final entries = <Object>[];
    DateTime? currentDay;
    for (final movement in movements) {
      if (currentDay == null || !Fmt.sameDay(currentDay, movement.createdAt)) {
        currentDay = movement.createdAt;
        entries.add(currentDay);
      }
      entries.add(movement);
    }
    return entries;
  }

  @override
  Widget build(BuildContext context) {
    final t = L.of(context).t;
    final provider = context.watch<ShoeProvider>();
    final entries = _entries(provider.movements);
    final sales = provider.sales;
    final selected = provider.movementTypeFilter;

    return RefreshIndicator(
      onRefresh: provider.refresh,
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            titleSpacing: 20,
            title: Text(t('movement_history')),
            actions: [
              IconButton(
                tooltip: t('settings'),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                ),
                icon: const Icon(Icons.settings_outlined),
              ),
              const SizedBox(width: 4),
            ],
          ),

          // Ventes enregistrées
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Container(
                decoration: AppTheme.cardDecoration(context),
                padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      t('sales_summary').toUpperCase(),
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.3,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _MiniStat(
                            label: t('sold_units'),
                            value: Fmt.number(sales.units),
                          ),
                        ),
                        Expanded(
                          child: _MiniStat(
                            label: t('revenue'),
                            value: Fmt.moneyShort(sales.revenue),
                          ),
                        ),
                        Expanded(
                          child: _MiniStat(
                            label: t('realized_profit'),
                            value: Fmt.moneyShort(sales.profit),
                            color: sales.profit >= 0
                                ? StockColors.profit
                                : StockColors.out,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Filtre entrées / sorties
          SliverToBoxAdapter(
            child: SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  _TypeChip(
                    label: t('movements_all'),
                    selected: selected == null,
                    onTap: () => provider.setMovementTypeFilter(null),
                  ),
                  _TypeChip(
                    label: t('movements_entries'),
                    selected: selected == MovementType.entry,
                    onTap: () =>
                        provider.setMovementTypeFilter(MovementType.entry),
                  ),
                  _TypeChip(
                    label: t('movements_exits'),
                    selected: selected == MovementType.exit,
                    onTap: () =>
                        provider.setMovementTypeFilter(MovementType.exit),
                  ),
                ],
              ),
            ),
          ),

          if (provider.loading)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (entries.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: EmptyState(
                icon: Icons.history_rounded,
                title: t('no_movements_title'),
                message: t('no_movements_msg'),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.only(bottom: 100),
              sliver: SliverList.builder(
                itemCount: entries.length,
                itemBuilder: (context, index) {
                  final entry = entries[index];
                  if (entry is DateTime) {
                    return MovementDayHeader(date: entry);
                  }
                  final movement = entry as StockMovement;
                  return MovementTile(
                    movement: movement,
                    showShoe: true,
                    onTap: () => _openShoe(movement.shoeId),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.label, required this.value, this.color});

  final String label;
  final String value;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(
            value,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w800,
              letterSpacing: -0.6,
              color: color,
            ),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          maxLines: 2,
          style: theme.textTheme.bodySmall
              ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

class _TypeChip extends StatelessWidget {
  const _TypeChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onTap(),
      ),
    );
  }
}
