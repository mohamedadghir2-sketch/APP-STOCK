import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/strings.dart';
import '../models/shoe.dart';
import '../providers/shoe_provider.dart';
import '../utils/formatters.dart';
import '../widgets/empty_state.dart';
import '../widgets/filter_sheet.dart';
import '../widgets/shoe_card.dart';
import '../widgets/summary_card.dart';
import 'settings_screen.dart';
import 'shoe_detail_screen.dart';
import 'shoe_form_screen.dart';

/// Onglet « Stock » : synthèse, recherche, filtres et liste complète.
class StockView extends StatefulWidget {
  const StockView({super.key});

  @override
  State<StockView> createState() => _StockViewState();
}

class _StockViewState extends State<StockView> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _openFilters(ShoeProvider provider) async {
    final result = await showFilterSheet(
      context,
      current: provider.filter,
      brands: provider.brands,
      colors: provider.colors,
      sizes: provider.sizes,
    );
    if (result != null) provider.applyFilter(result);
  }

  void _openDetail(Shoe shoe) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ShoeDetailScreen(shoe: shoe)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = L.of(context);
    final t = l.t;
    final provider = context.watch<ShoeProvider>();
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final filter = provider.filter;

    return RefreshIndicator(
      onRefresh: provider.refresh,
      child: CustomScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        slivers: [
          SliverAppBar(
            pinned: true,
            titleSpacing: 20,
            title: Text(t('my_stock')),
            actions: [
              IconButton(
                tooltip: t('filter_sort'),
                onPressed: () => _openFilters(provider),
                icon: Badge(
                  isLabelVisible: filter.hasFilters,
                  label: Text('${filter.activeCount}'),
                  child: const Icon(Icons.tune_rounded),
                ),
              ),
              IconButton(
                tooltip: t('settings'),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                ),
                icon: const Icon(Icons.settings_outlined),
              ),
              const SizedBox(width: 4),
            ],
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(70),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: TextField(
                  controller: _searchController,
                  textInputAction: TextInputAction.search,
                  onChanged: provider.search,
                  decoration: InputDecoration(
                    hintText: t('search_hint'),
                    prefixIcon: const Icon(Icons.search_rounded),
                    suffixIcon: filter.hasSearch
                        ? IconButton(
                            tooltip: t('clear_search'),
                            icon: const Icon(Icons.close_rounded),
                            onPressed: () {
                              _searchController.clear();
                              provider.clearSearch();
                              FocusScope.of(context).unfocus();
                            },
                          )
                        : null,
                  ),
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              child: provider.isFiltered
                  ? SummaryCard(
                      label: t('selection_shown'),
                      references: provider.shoes.length,
                      items: provider.visibleItems,
                      purchaseValue: provider.visiblePurchaseValue,
                      saleValue: provider.visibleSaleValue,
                    )
                  : SummaryCard(
                      label: t('total_stock_value'),
                      references: provider.summary.references,
                      items: provider.summary.items,
                      purchaseValue: provider.summary.purchaseValue,
                      saleValue: provider.summary.saleValue,
                    ),
            ),
          ),

          if (filter.hasFilters)
            SliverToBoxAdapter(
              child: SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    for (final brand in filter.brands)
                      _ActiveChip(
                        label: brand,
                        onRemoved: () => provider.toggleBrand(brand),
                      ),
                    for (final color in filter.colors)
                      _ActiveChip(
                        label: color,
                        onRemoved: () => provider.toggleColor(color),
                      ),
                    for (final size in filter.sizes)
                      _ActiveChip(
                        label: t('size_short', {'n': Fmt.size(size)}),
                        onRemoved: () => provider.toggleSize(size),
                      ),
                    if (filter.onlyLowStock)
                      _ActiveChip(
                        label: t('low_stock'),
                        onRemoved: () => provider.applyFilter(
                          filter.copyWith(onlyLowStock: false),
                        ),
                      ),
                    TextButton(
                      onPressed: provider.clearFilters,
                      child: Text(t('clear_all')),
                    ),
                  ],
                ),
              ),
            ),

          if (!provider.loading && provider.shoes.isNotEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 10),
                child: Row(
                  children: [
                    Text(
                      l.plural(provider.shoes.length, 'reference'),
                      style: theme.textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: () => _openFilters(provider),
                      icon: const Icon(Icons.swap_vert_rounded, size: 18),
                      label: Text(t(filter.sort.key)),
                      style: TextButton.styleFrom(
                        foregroundColor: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),

          if (provider.loading)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (provider.shoes.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: provider.isFiltered
                  ? EmptyState(
                      icon: Icons.search_off_rounded,
                      title: t('no_results_title'),
                      message: t('no_results_msg'),
                      actionLabel: t('reset'),
                      onAction: () {
                        _searchController.clear();
                        provider.applyFilter(
                          provider.filter.cleared().copyWith(search: ''),
                        );
                      },
                    )
                  : EmptyState(
                      icon: Icons.inventory_2_outlined,
                      title: t('empty_stock_title'),
                      message: t('empty_stock_msg'),
                      actionLabel: t('add_shoe'),
                      onAction: () => Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (_) => const ShoeFormScreen()),
                      ),
                    ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 120),
              sliver: SliverList.separated(
                itemCount: provider.shoes.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) => ShoeCard(
                  shoe: provider.shoes[index],
                  onTap: () => _openDetail(provider.shoes[index]),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ActiveChip extends StatelessWidget {
  const _ActiveChip({required this.label, required this.onRemoved});

  final String label;
  final VoidCallback onRemoved;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: Chip(
        label: Text(label),
        onDeleted: onRemoved,
        deleteIcon: const Icon(Icons.close_rounded, size: 16),
        visualDensity: VisualDensity.compact,
      ),
    );
  }
}
