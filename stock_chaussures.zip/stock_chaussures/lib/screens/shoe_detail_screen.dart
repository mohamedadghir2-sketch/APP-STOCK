import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/strings.dart';
import '../models/shoe.dart';
import '../models/stock_movement.dart';
import '../providers/shoe_provider.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../utils/formatters.dart';
import '../widgets/movement_sheet.dart';
import '../widgets/movement_tile.dart';
import '../widgets/shoe_card.dart';
import '../widgets/shoe_photo.dart';
import 'shoe_form_screen.dart';

/// Fiche complète : caractéristiques, finances, mouvements et historique.
class ShoeDetailScreen extends StatefulWidget {
  const ShoeDetailScreen({super.key, required this.shoe});

  final Shoe shoe;

  @override
  State<ShoeDetailScreen> createState() => _ShoeDetailScreenState();
}

class _ShoeDetailScreenState extends State<ShoeDetailScreen> {
  late Shoe _shoe = widget.shoe;
  List<StockMovement> _movements = [];

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final provider = context.read<ShoeProvider>();
    final fresh = await provider.byId(_shoe.id!);
    final movements = await provider.movementsForShoe(_shoe.id!, limit: 12);
    if (!mounted) return;
    setState(() {
      if (fresh != null) _shoe = fresh;
      _movements = movements;
    });
  }

  Future<void> _edit() async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => ShoeFormScreen(shoe: _shoe)),
    );
    if (saved == true) await _reload();
  }

  Future<void> _declare(MovementType type) async {
    final recorded =
        await showMovementSheet(context, shoe: _shoe, type: type);
    if (recorded == true) await _reload();
  }

  Future<void> _confirmDelete() async {
    final t = L.of(context).t;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(t('delete_confirm_title')),
        content: Text(t('delete_confirm_msg', {
          'name': _shoe.title,
          'size': t('size_full', {'n': Fmt.size(_shoe.size)}),
        })),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(t('cancel')),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: StockColors.out),
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(t('delete')),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    await context.read<ShoeProvider>().delete(_shoe);
    navigator.pop();
    messenger
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(content: Text(t('deleted', {'name': _shoe.title}))),
      );
  }

  @override
  Widget build(BuildContext context) {
    final t = L.of(context).t;
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final dotColor = colorFromName(_shoe.color);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 300,
            backgroundColor: scheme.surface,
            foregroundColor: Colors.white,
            iconTheme: const IconThemeData(color: Colors.white),
            actionsIconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  ShoePhoto(
                    fileName: _shoe.photo,
                    width: double.infinity,
                    height: double.infinity,
                    radius: 0,
                    iconSize: 56,
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0x99000000), Color(0x00000000)],
                        stops: [0, 0.4],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              IconButton(
                tooltip: t('edit_sheet'),
                onPressed: _edit,
                icon: const Icon(Icons.edit_outlined),
              ),
              IconButton(
                tooltip: t('delete'),
                onPressed: _confirmDelete,
                icon: const Icon(Icons.delete_outline_rounded),
              ),
              const SizedBox(width: 4),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _shoe.brand.toUpperCase(),
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: scheme.onSurfaceVariant,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.4,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _shoe.model,
                    style: theme.textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.8,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      QuantityPill(quantity: _shoe.quantity, large: true),
                      MetaChip(
                        label: _shoe.color,
                        leading:
                            dotColor == null ? null : ColorDot(color: dotColor),
                      ),
                      MetaChip(
                        label: t('size_full', {'n': Fmt.size(_shoe.size)}),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Mouvements de stock
                  Container(
                    width: double.infinity,
                    decoration: AppTheme.cardDecoration(context),
                    padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t('quantity_remaining'),
                          style: theme.textTheme.titleSmall
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          t('movement_hint'),
                          style: theme.textTheme.bodySmall
                              ?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                        const SizedBox(height: 14),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: () =>
                                    _declare(MovementType.entry),
                                style: FilledButton.styleFrom(
                                  backgroundColor: StockColors.ok,
                                ),
                                icon: const Icon(Icons.south_west_rounded,
                                    size: 18),
                                label: Text(t('movement_entry')),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: _shoe.quantity > 0
                                    ? () => _declare(MovementType.exit)
                                    : null,
                                style: FilledButton.styleFrom(
                                  backgroundColor: StockColors.low,
                                ),
                                icon: const Icon(Icons.north_east_rounded,
                                    size: 18),
                                label: Text(t('movement_exit')),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          t('quantity_locked_hint'),
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: scheme.onSurfaceVariant,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Finances
                  Container(
                    decoration: AppTheme.cardDecoration(context),
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 10),
                    child: Column(
                      children: [
                        _InfoRow(
                          label: t('unit_purchase_price'),
                          value: Fmt.money(_shoe.purchasePrice),
                        ),
                        const Divider(height: 1),
                        _InfoRow(
                          label: t('unit_sale_price'),
                          value: Fmt.money(_shoe.salePrice),
                        ),
                        const Divider(height: 1),
                        _InfoRow(
                          label: t('unit_margin'),
                          value: '${Fmt.money(_shoe.unitMargin)}'
                              '  (${Fmt.percent(_shoe.marginRate)})',
                          color: _shoe.unitMargin >= 0
                              ? StockColors.profit
                              : StockColors.out,
                        ),
                        const Divider(height: 1),
                        _InfoRow(
                          label: t('stock_value'),
                          value: Fmt.money(_shoe.stockValue),
                        ),
                        const Divider(height: 1),
                        _InfoRow(
                          label: t('potential_sale'),
                          value: Fmt.money(_shoe.potentialRevenue),
                        ),
                        const Divider(height: 1),
                        _InfoRow(
                          label: t('potential_profit'),
                          value: Fmt.money(_shoe.potentialProfit),
                          emphasis: true,
                          color: _shoe.potentialProfit >= 0
                              ? StockColors.profit
                              : StockColors.out,
                        ),
                      ],
                    ),
                  ),

                  if ((_shoe.note ?? '').trim().isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      decoration: AppTheme.cardDecoration(context),
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            t('note').toUpperCase(),
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: scheme.onSurfaceVariant,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.3,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(_shoe.note!.trim()),
                        ],
                      ),
                    ),
                  ],

                  // Historique de la référence
                  const SizedBox(height: 24),
                  Text(
                    t('history'),
                    style: theme.textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 10),
                  if (_movements.isEmpty)
                    Text(
                      t('no_movements_msg'),
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: scheme.onSurfaceVariant),
                    )
                  else
                    Container(
                      decoration: AppTheme.cardDecoration(context),
                      clipBehavior: Clip.antiAlias,
                      child: Column(
                        children: [
                          for (var i = 0; i < _movements.length; i++) ...[
                            if (i > 0) const Divider(height: 1, indent: 72),
                            MovementTile(movement: _movements[i]),
                          ],
                        ],
                      ),
                    ),

                  const SizedBox(height: 18),
                  Text(
                    t('added_modified', {
                      'added': Fmt.date(_shoe.createdAt),
                      'updated': Fmt.date(_shoe.updatedAt),
                    }),
                    style: theme.textTheme.bodySmall
                        ?.copyWith(color: scheme.onSurfaceVariant),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _edit,
                      icon: const Icon(Icons.edit_outlined),
                      label: Text(t('edit_sheet')),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
    this.emphasis = false,
    this.color,
  });

  final String label;
  final String value;
  final bool emphasis;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: theme.textTheme.bodyMedium
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            value,
            style: (emphasis
                    ? theme.textTheme.titleMedium
                    : theme.textTheme.bodyLarge)
                ?.copyWith(
              fontWeight: emphasis ? FontWeight.w800 : FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
