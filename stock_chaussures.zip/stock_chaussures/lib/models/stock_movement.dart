/// Sens d'un mouvement de stock.
enum MovementType { entry, exit }

/// Motif d'un mouvement. Chaque motif appartient à un sens et porte la clé
/// de traduction correspondante.
enum MovementReason {
  purchase(MovementType.entry, 'reason_purchase'),
  restock(MovementType.entry, 'reason_restock'),
  customerReturn(MovementType.entry, 'reason_customer_return'),
  initialStock(MovementType.entry, 'reason_initial'),
  inventoryPlus(MovementType.entry, 'reason_inventory_plus'),
  sale(MovementType.exit, 'reason_sale'),
  supplierReturn(MovementType.exit, 'reason_supplier_return'),
  loss(MovementType.exit, 'reason_loss'),
  damage(MovementType.exit, 'reason_damage'),
  inventoryMinus(MovementType.exit, 'reason_inventory_minus');

  const MovementReason(this.type, this.key);

  final MovementType type;

  /// Clé de traduction (voir `lib/l10n/strings.dart`).
  final String key;

  static List<MovementReason> forType(MovementType type) =>
      values.where((reason) => reason.type == type).toList();

  static MovementReason parse(String? name, MovementType fallbackType) {
    return values.firstWhere(
      (reason) => reason.name == name,
      orElse: () => fallbackType == MovementType.entry ? purchase : sale,
    );
  }
}

/// Une ligne du journal de stock : qui, quoi, combien, quand, et le stock
/// résultant. Immuable : on n'édite jamais un mouvement, on en ajoute un.
class StockMovement {
  final int? id;
  final int shoeId;
  final MovementType type;
  final MovementReason reason;

  /// Toujours positif : le sens est porté par [type].
  final int quantity;

  /// Prix unitaire appliqué au mouvement (vente, achat…), facultatif.
  final double? unitPrice;

  /// Stock de la référence juste après ce mouvement (piste d'audit).
  final int quantityAfter;

  final String? note;
  final DateTime createdAt;

  // Champs joints depuis la table `shoes` pour l'affichage de l'historique
  // global (non persistés dans la table `movements`).
  final String? shoeBrand;
  final String? shoeModel;
  final double? shoeSize;
  final String? shoeColor;
  final String? shoePhoto;

  const StockMovement({
    this.id,
    required this.shoeId,
    required this.type,
    required this.reason,
    required this.quantity,
    this.unitPrice,
    required this.quantityAfter,
    this.note,
    required this.createdAt,
    this.shoeBrand,
    this.shoeModel,
    this.shoeSize,
    this.shoeColor,
    this.shoePhoto,
  });

  bool get isEntry => type == MovementType.entry;

  /// +3 ou −2, pour l'affichage et les cumuls.
  int get signedQuantity => isEntry ? quantity : -quantity;

  double get total => (unitPrice ?? 0) * quantity;

  String get shoeLabel =>
      '${shoeBrand ?? ''} ${shoeModel ?? ''}'.trim();

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'shoe_id': shoeId,
        'type': type.name,
        'reason': reason.name,
        'quantity': quantity,
        'unit_price': unitPrice,
        'quantity_after': quantityAfter,
        'note': note,
        'created_at': createdAt.toIso8601String(),
      };

  factory StockMovement.fromMap(Map<String, Object?> map) {
    final type = (map['type'] as String?) == MovementType.exit.name
        ? MovementType.exit
        : MovementType.entry;
    return StockMovement(
      id: map['id'] as int?,
      shoeId: (map['shoe_id'] as num?)?.toInt() ?? 0,
      type: type,
      reason: MovementReason.parse(map['reason'] as String?, type),
      quantity: (map['quantity'] as num?)?.toInt() ?? 0,
      unitPrice: (map['unit_price'] as num?)?.toDouble(),
      quantityAfter: (map['quantity_after'] as num?)?.toInt() ?? 0,
      note: map['note'] as String?,
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ??
          DateTime.now(),
      shoeBrand: map['brand'] as String?,
      shoeModel: map['model'] as String?,
      shoeSize: (map['size'] as num?)?.toDouble(),
      shoeColor: map['color'] as String?,
      shoePhoto: map['photo'] as String?,
    );
  }
}

/// Totaux des ventes réellement enregistrées (mouvements de motif « vente »).
class SalesSummary {
  final int units;
  final double revenue;
  final double cost;

  const SalesSummary({this.units = 0, this.revenue = 0, this.cost = 0});

  static const SalesSummary empty = SalesSummary();

  double get profit => revenue - cost;

  factory SalesSummary.fromRow(Map<String, Object?> row) => SalesSummary(
        units: (row['units'] as num?)?.toInt() ?? 0,
        revenue: (row['revenue'] as num?)?.toDouble() ?? 0,
        cost: (row['cost'] as num?)?.toDouble() ?? 0,
      );
}

/// Levée quand une sortie dépasse le stock disponible.
class InsufficientStockException implements Exception {
  const InsufficientStockException(this.available);

  final int available;

  @override
  String toString() => 'InsufficientStockException(available: $available)';
}
