import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/shoe.dart';
import '../models/shoe_filter.dart';
import '../models/stock_movement.dart';
import '../models/stock_summary.dart';
import '../utils/constants.dart';

/// Accès à la base SQLite locale (aucune connexion réseau nécessaire).
///
/// Règle d'or : la colonne `shoes.quantity` n'est JAMAIS modifiée directement.
/// Elle est le reflet du journal `movements` et ne change qu'à travers
/// [recordMovement] ou [createShoe], dans une transaction.
class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static const String _dbName = 'stock_chaussures.db';
  static const int _dbVersion = 2;
  static const String shoesTable = 'shoes';
  static const String movementsTable = 'movements';
  static const String settingsTable = 'settings';

  Database? _database;

  Future<Database> get database async => _database ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), _dbName);
    return openDatabase(
      path,
      version: _dbVersion,
      onConfigure: (db) => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await _createShoes(db);
    await _createMovements(db);
    await _createSettings(db);
  }

  Future<void> _createShoes(Database db) async {
    await db.execute('''
      CREATE TABLE $shoesTable (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        brand          TEXT    NOT NULL,
        model          TEXT    NOT NULL,
        color          TEXT    NOT NULL,
        size           REAL    NOT NULL,
        quantity       INTEGER NOT NULL DEFAULT 0,
        purchase_price REAL    NOT NULL DEFAULT 0,
        sale_price     REAL    NOT NULL DEFAULT 0,
        photo          TEXT,
        note           TEXT,
        created_at     TEXT    NOT NULL,
        updated_at     TEXT    NOT NULL
      )
    ''');
    await db.execute('CREATE INDEX idx_shoes_brand ON $shoesTable(brand)');
    await db.execute('CREATE INDEX idx_shoes_color ON $shoesTable(color)');
    await db.execute('CREATE INDEX idx_shoes_size ON $shoesTable(size)');
    await db.execute('CREATE INDEX idx_shoes_model ON $shoesTable(model)');
  }

  Future<void> _createMovements(Database db) async {
    await db.execute('''
      CREATE TABLE $movementsTable (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        shoe_id        INTEGER NOT NULL,
        type           TEXT    NOT NULL,
        reason         TEXT    NOT NULL,
        quantity       INTEGER NOT NULL,
        unit_price     REAL,
        quantity_after INTEGER NOT NULL,
        note           TEXT,
        created_at     TEXT    NOT NULL,
        FOREIGN KEY (shoe_id) REFERENCES $shoesTable(id) ON DELETE CASCADE
      )
    ''');
    await db.execute(
        'CREATE INDEX idx_mov_shoe ON $movementsTable(shoe_id)');
    await db.execute(
        'CREATE INDEX idx_mov_date ON $movementsTable(created_at)');
    await db.execute(
        'CREATE INDEX idx_mov_reason ON $movementsTable(reason)');
  }

  Future<void> _createSettings(Database db) async {
    await db.execute('''
      CREATE TABLE $settingsTable (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');
  }

  /// v1 → v2 : ajout du journal des mouvements et des réglages.
  /// Le stock existant est converti en une entrée « stock initial » afin que
  /// l'historique reste cohérent avec les quantités déjà saisies.
  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await _createMovements(db);
      await _createSettings(db);
      final shoes = await db.query(shoesTable,
          columns: ['id', 'quantity', 'purchase_price', 'created_at']);
      for (final row in shoes) {
        final quantity = (row['quantity'] as num?)?.toInt() ?? 0;
        if (quantity <= 0) continue;
        await db.insert(movementsTable, {
          'shoe_id': row['id'],
          'type': MovementType.entry.name,
          'reason': MovementReason.initialStock.name,
          'quantity': quantity,
          'unit_price': row['purchase_price'],
          'quantity_after': quantity,
          'note': null,
          'created_at':
              row['created_at'] as String? ?? DateTime.now().toIso8601String(),
        });
      }
    }
  }

  // --- Lecture du stock ---------------------------------------------------

  Future<List<Shoe>> fetchShoes(ShoeFilter filter) async {
    final db = await database;
    final where = <String>[];
    final args = <Object?>[];

    if (filter.hasSearch) {
      final terms = filter.search.trim().toLowerCase().split(RegExp(r'\s+'));
      for (final term in terms) {
        where.add('(LOWER(brand) LIKE ? OR LOWER(model) LIKE ? '
            'OR LOWER(color) LIKE ? OR CAST(size AS TEXT) LIKE ?)');
        final like = '%$term%';
        args.addAll([like, like, like, like]);
      }
    }
    if (filter.brands.isNotEmpty) {
      where.add('brand IN (${_placeholders(filter.brands.length)})');
      args.addAll(filter.brands);
    }
    if (filter.colors.isNotEmpty) {
      where.add('color IN (${_placeholders(filter.colors.length)})');
      args.addAll(filter.colors);
    }
    if (filter.sizes.isNotEmpty) {
      where.add('size IN (${_placeholders(filter.sizes.length)})');
      args.addAll(filter.sizes);
    }
    if (filter.onlyLowStock) {
      where.add('quantity <= ?');
      args.add(kLowStockThreshold);
    }

    final rows = await db.query(
      shoesTable,
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: where.isEmpty ? null : args,
      orderBy: _orderBy(filter.sort),
    );
    return rows.map(Shoe.fromMap).toList();
  }

  Future<Shoe?> findById(int id) async {
    final db = await database;
    final rows =
        await db.query(shoesTable, where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : Shoe.fromMap(rows.first);
  }

  Future<List<String>> distinctText(String column) async {
    final db = await database;
    final rows = await db.rawQuery(
      "SELECT DISTINCT $column AS value FROM $shoesTable "
      "WHERE TRIM($column) <> '' ORDER BY value COLLATE NOCASE ASC",
    );
    return rows.map((row) => row['value'] as String).toList();
  }

  Future<List<double>> distinctSizes() async {
    final db = await database;
    final rows = await db.rawQuery(
        'SELECT DISTINCT size AS value FROM $shoesTable ORDER BY value ASC');
    return rows.map((row) => (row['value'] as num).toDouble()).toList();
  }

  Future<StockSummary> summary() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT
        COUNT(*)                                    AS refs,
        COALESCE(SUM(quantity), 0)                  AS items,
        COALESCE(SUM(quantity * purchase_price), 0) AS buy,
        COALESCE(SUM(quantity * sale_price), 0)     AS sell,
        COALESCE(SUM(CASE WHEN quantity > 0 AND quantity <= $kLowStockThreshold
                          THEN 1 ELSE 0 END), 0)    AS low,
        COALESCE(SUM(CASE WHEN quantity <= 0 THEN 1 ELSE 0 END), 0) AS out
      FROM $shoesTable
    ''');
    return StockSummary.fromRow(rows.first);
  }

  Future<List<BrandStat>> brandStats() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT
        brand,
        COUNT(*)                                    AS refs,
        COALESCE(SUM(quantity), 0)                  AS items,
        COALESCE(SUM(quantity * purchase_price), 0) AS buy,
        COALESCE(SUM(quantity * sale_price), 0)     AS sell
      FROM $shoesTable
      GROUP BY brand
      ORDER BY buy DESC, brand COLLATE NOCASE ASC
    ''');
    return rows.map(BrandStat.fromRow).toList();
  }

  Future<List<Shoe>> lowStock({int limit = 20}) async {
    final db = await database;
    final rows = await db.query(
      shoesTable,
      where: 'quantity <= ?',
      whereArgs: [kLowStockThreshold],
      orderBy: 'quantity ASC, brand COLLATE NOCASE ASC',
      limit: limit,
    );
    return rows.map(Shoe.fromMap).toList();
  }

  // --- Écriture du stock --------------------------------------------------

  /// Crée une référence. Si [initialQuantity] > 0, une entrée « stock initial »
  /// est enregistrée dans le même mouvement transactionnel.
  Future<int> createShoe(Shoe shoe, {int initialQuantity = 0}) async {
    final db = await database;
    final now = DateTime.now();
    return db.transaction((txn) async {
      final id = await txn.insert(shoesTable, {
        ...shoe.copyWith(createdAt: now, updatedAt: now).toMap(),
        'quantity': 0,
      }..remove('id'));

      if (initialQuantity > 0) {
        await txn.insert(movementsTable, {
          'shoe_id': id,
          'type': MovementType.entry.name,
          'reason': MovementReason.initialStock.name,
          'quantity': initialQuantity,
          'unit_price': shoe.purchasePrice,
          'quantity_after': initialQuantity,
          'note': null,
          'created_at': now.toIso8601String(),
        });
        await txn.update(
          shoesTable,
          {'quantity': initialQuantity, 'updated_at': now.toIso8601String()},
          where: 'id = ?',
          whereArgs: [id],
        );
      }
      return id;
    });
  }

  /// Met à jour la fiche produit **sans** toucher à la quantité : celle-ci
  /// n'évolue que par un mouvement déclaré.
  Future<int> updateShoe(Shoe shoe) async {
    final db = await database;
    final values = shoe.copyWith(updatedAt: DateTime.now()).toMap()
      ..remove('id')
      ..remove('quantity')
      ..remove('created_at');
    return db.update(shoesTable, values, where: 'id = ?', whereArgs: [shoe.id]);
  }

  /// Supprime la référence et, par cascade, tout son historique.
  Future<int> deleteShoe(int id) async {
    final db = await database;
    return db.delete(shoesTable, where: 'id = ?', whereArgs: [id]);
  }

  // --- Journal des mouvements ---------------------------------------------

  /// Enregistre une entrée ou une sortie et met à jour le stock dans la même
  /// transaction. Lève [InsufficientStockException] si la sortie dépasse le
  /// stock disponible : aucune quantité négative n'est possible.
  Future<int> recordMovement({
    required int shoeId,
    required MovementType type,
    required MovementReason reason,
    required int quantity,
    double? unitPrice,
    String? note,
    DateTime? date,
  }) async {
    if (quantity <= 0) throw ArgumentError('quantity must be > 0');
    final db = await database;
    final now = date ?? DateTime.now();

    return db.transaction<int>((txn) async {
      final rows = await txn.query(
        shoesTable,
        columns: ['quantity'],
        where: 'id = ?',
        whereArgs: [shoeId],
        limit: 1,
      );
      if (rows.isEmpty) throw StateError('Shoe $shoeId not found');
      final current = (rows.first['quantity'] as num?)?.toInt() ?? 0;
      final next =
          type == MovementType.entry ? current + quantity : current - quantity;
      if (next < 0) throw InsufficientStockException(current);

      await txn.insert(movementsTable, {
        'shoe_id': shoeId,
        'type': type.name,
        'reason': reason.name,
        'quantity': quantity,
        'unit_price': unitPrice,
        'quantity_after': next,
        'note': (note == null || note.trim().isEmpty) ? null : note.trim(),
        'created_at': now.toIso8601String(),
      });
      await txn.update(
        shoesTable,
        {'quantity': next, 'updated_at': DateTime.now().toIso8601String()},
        where: 'id = ?',
        whereArgs: [shoeId],
      );
      return next;
    });
  }

  Future<List<StockMovement>> movementsForShoe(int shoeId,
      {int limit = 100}) async {
    final db = await database;
    final rows = await db.query(
      movementsTable,
      where: 'shoe_id = ?',
      whereArgs: [shoeId],
      orderBy: 'created_at DESC, id DESC',
      limit: limit,
    );
    return rows.map(StockMovement.fromMap).toList();
  }

  /// Historique global, enrichi des informations de la chaussure.
  Future<List<StockMovement>> allMovements({
    MovementType? type,
    int limit = 300,
  }) async {
    final db = await database;
    final where = type == null ? '' : 'WHERE m.type = ?';
    final args = type == null ? <Object?>[] : <Object?>[type.name];
    final rows = await db.rawQuery('''
      SELECT m.*, s.brand, s.model, s.size, s.color, s.photo
      FROM $movementsTable m
      JOIN $shoesTable s ON s.id = m.shoe_id
      $where
      ORDER BY m.created_at DESC, m.id DESC
      LIMIT $limit
    ''', args);
    return rows.map(StockMovement.fromMap).toList();
  }

  /// Ventes réellement enregistrées (motif « vente »).
  Future<SalesSummary> salesSummary() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT
        COALESCE(SUM(m.quantity), 0)                                   AS units,
        COALESCE(SUM(m.quantity * COALESCE(m.unit_price, s.sale_price)), 0)
                                                                       AS revenue,
        COALESCE(SUM(m.quantity * s.purchase_price), 0)                AS cost
      FROM $movementsTable m
      JOIN $shoesTable s ON s.id = m.shoe_id
      WHERE m.reason = ?
    ''', [MovementReason.sale.name]);
    return SalesSummary.fromRow(rows.first);
  }

  /// Filet de sécurité : recalcule chaque quantité depuis le journal.
  /// Renvoie le nombre de références corrigées.
  Future<int> recalculateQuantities() async {
    final db = await database;
    return db.transaction<int>((txn) async {
      final rows = await txn.rawQuery('''
        SELECT s.id AS id, s.quantity AS stored,
          COALESCE((
            SELECT SUM(CASE WHEN m.type = '${MovementType.entry.name}'
                            THEN m.quantity ELSE -m.quantity END)
            FROM $movementsTable m WHERE m.shoe_id = s.id
          ), 0) AS computed
        FROM $shoesTable s
      ''');
      var fixed = 0;
      for (final row in rows) {
        final stored = (row['stored'] as num?)?.toInt() ?? 0;
        final computed = (row['computed'] as num?)?.toInt() ?? 0;
        if (stored != computed) {
          await txn.update(
            shoesTable,
            {'quantity': computed < 0 ? 0 : computed},
            where: 'id = ?',
            whereArgs: [row['id']],
          );
          fixed++;
        }
      }
      return fixed;
    });
  }

  // --- Réglages -----------------------------------------------------------

  Future<String?> readSetting(String key) async {
    final db = await database;
    final rows = await db.query(settingsTable,
        where: 'key = ?', whereArgs: [key], limit: 1);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  Future<void> writeSetting(String key, String value) async {
    final db = await database;
    await db.insert(
      settingsTable,
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // --- Helpers ------------------------------------------------------------

  String _placeholders(int count) => List.filled(count, '?').join(', ');

  String _orderBy(SortOption sort) {
    switch (sort) {
      case SortOption.brandAsc:
        return 'brand COLLATE NOCASE ASC, model COLLATE NOCASE ASC, size ASC';
      case SortOption.quantityDesc:
        return 'quantity DESC, brand COLLATE NOCASE ASC';
      case SortOption.quantityAsc:
        return 'quantity ASC, brand COLLATE NOCASE ASC';
      case SortOption.valueDesc:
        return '(quantity * purchase_price) DESC';
      case SortOption.profitDesc:
        return '((sale_price - purchase_price) * quantity) DESC';
      case SortOption.recent:
        return 'updated_at DESC';
    }
  }
}
