import 'dart:ui';

import 'package:flutter/foundation.dart';

import '../data/database_helper.dart';
import '../utils/formatters.dart';

/// Réglages persistés dans la table `settings` de la base locale.
class SettingsProvider extends ChangeNotifier {
  SettingsProvider({DatabaseHelper? db}) : _db = db ?? DatabaseHelper.instance;

  static const String languageKey = 'language';
  static const List<String> supportedLanguages = ['fr', 'es'];

  final DatabaseHelper _db;

  String _language = 'fr';

  String get language => _language;
  Locale get locale => Locale(_language);

  /// Charge la langue enregistrée, sinon celle du téléphone si elle est
  /// prise en charge, sinon le français.
  Future<void> load() async {
    final stored = await _db.readSetting(languageKey);
    final device = PlatformDispatcher.instance.locale.languageCode;
    _language = supportedLanguages.contains(stored)
        ? stored!
        : (supportedLanguages.contains(device) ? device : 'fr');
    Fmt.setLanguage(_language);
    notifyListeners();
  }

  Future<void> setLanguage(String code) async {
    if (!supportedLanguages.contains(code) || code == _language) return;
    _language = code;
    Fmt.setLanguage(code);
    notifyListeners();
    await _db.writeSetting(languageKey, code);
  }
}
