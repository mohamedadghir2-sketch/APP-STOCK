import 'dart:async';

import 'package:flutter/foundation.dart';

import '../data/database_helper.dart';
import '../models/shoe.dart';
import '../models/shoe_filter.dart';
import '../models/stock_movement.dart';
import '../models/stock_summary.dart';
import '../utils/photo_storage.dart';

/// Source unique de vérité pour le stock et son journal.
///
/// Aucune méthode ne permet de fixer une quantité « à la main » :
/// tout passe par [recordMovement].
class ShoeProvider extends ChangeNotifier {
  ShoeProvider({DatabaseHelper? db}) : _db = db ?? DatabaseHelper.instance;

  final DatabaseHelper _db;

  List<Shoe> _shoes = [];
  StockSummary _summary = StockSummary.empty;
  SalesSummary _sales = SalesSummary.empty;
  List<BrandStat> _brandStats = [];
  List<Shoe> _lowStock = [];
  List<StockMovement> _movements = [];
  List<String> _brands = [];
  List<String> _colors = [];
  List<double> _sizes = [];
  ShoeFilter _filter = const ShoeFilter();
  MovementType? _movementTypeFilter;
  bool _loading = true;
  Timer? _searchDebounce;

  // --- Lecture publique ---------------------------------------------------

  List<Shoe> get shoes => _shoes;
  StockSummary get summary => _summary;
  SalesSummary get sales => _sales;
  List<BrandStat> get brandStats => _brandStats;
  List<Shoe> get lowStock => _lowStock;
  List<StockMovement> get movements => _movements;
  List<String> get brands => _brands;
  List<String> get colors => _colors;
  List<double> get sizes => _sizes;
  ShoeFilter get filter => _filter;
  MovementType? get movementTypeFilter => _movementTypeFilter;
  bool get loading => _loading;

  bool get isFiltered => _filter.hasFilters || _filter.hasSearch;
  bool get isEmptyStock => _summary.references == 0;

  int get visibleItems => _shoes.fold(0, (sum, shoe) => sum + shoe.quantity);
  double get visiblePurchaseValue =>
      _shoes.fold<double>(0, (sum, shoe) => sum + shoe.stockValue);
  double get visibleSaleValue =>
      _shoes.fold<double>(0, (sum, shoe) => sum + shoe.potentialRevenue);
  double get visibleProfit => visibleSaleValue - visiblePurchaseValue;

  // --- Chargement ---------------------------------------------------------

  Future<void> refresh({bool showLoader = false}) async {
    if (showLoader) {
      _loading = true;
      notifyListeners();
    }
    final results = await Future.wait([
      _db.fetchShoes(_filter),
      _db.summary(),
      _db.distinctText('brand'),
      _db.distinctText('color'),
      _db.distinctSizes(),
      _db.brandStats(),
      _db.lowStock(),
      _db.allMovements(type: _movementTypeFilter),
      _db.salesSummary(),
    ]);
    _shoes = results[0] as List<Shoe>;
    _summary = results[1] as StockSummary;
    _brands = results[2] as List<String>;
    _colors = results[3] as List<String>;
    _sizes = results[4] as List<double>;
    _brandStats = results[5] as List<BrandStat>;
    _lowStock = results[6] as List<Shoe>;
    _movements = results[7] as List<StockMovement>;
    _sales = results[8] as SalesSummary;
    _loading = false;
    notifyListeners();
  }

  // --- Recherche & filtres ------------------------------------------------

  void search(String value) {
    _filter = _filter.copyWith(search: value);
    notifyListeners();
    _searchDebounce?.cancel();
    _searchDebounce =
        Timer(const Duration(milliseconds: 250), () => refresh());
  }

  void applyFilter(ShoeFilter filter) {
    _filter = filter;
    refresh();
  }

  void setSort(SortOption sort) => applyFilter(_filter.copyWith(sort: sort));

  void toggleBrand(String brand) {
    final next = Set<String>.from(_filter.brands);
    next.contains(brand) ? next.remove(brand) : next.add(brand);
    applyFilter(_filter.copyWith(brands: next));
  }

  void toggleColor(String color) {
    final next = Set<String>.from(_filter.colors);
    next.contains(color) ? next.remove(color) : next.add(color);
    applyFilter(_filter.copyWith(colors: next));
  }

  void toggleSize(double size) {
    final next = Set<double>.from(_filter.sizes);
    next.contains(size) ? next.remove(size) : next.add(size);
    applyFilter(_filter.copyWith(sizes: next));
  }

  void clearFilters() => applyFilter(_filter.cleared());

  void clearSearch() {
    _filter = _filter.copyWith(search: '');
    refresh();
  }

  void setMovementTypeFilter(MovementType? type) {
    _movementTypeFilter = type;
    refresh();
  }

  // --- Écriture -----------------------------------------------------------

  /// Création d'une référence. [initialQuantity] génère une entrée tracée
  /// « stock initial ».
  Future<int> create(Shoe shoe, {int initialQuantity = 0}) async {
    final id = await _db.createShoe(shoe, initialQuantity: initialQuantity);
    await refresh();
    return id;
  }

  /// Modification de la fiche (la quantité n'est pas concernée).
  Future<void> update(Shoe shoe) async {
    await _db.updateShoe(shoe);
    await refresh();
  }

  Future<void> delete(Shoe shoe) async {
    if (shoe.id == null) return;
    await _db.deleteShoe(shoe.id!);
    await PhotoStorage.delete(shoe.photo);
    await refresh();
  }

  /// Seul point d'entrée pour faire varier un stock.
  /// Lève [InsufficientStockException] si la sortie dépasse le disponible.
  Future<int> recordMovement({
    required int shoeId,
    required MovementType type,
    required MovementReason reason,
    required int quantity,
    double? unitPrice,
    String? note,
  }) async {
    final newQuantity = await _db.recordMovement(
      shoeId: shoeId,
      type: type,
      reason: reason,
      quantity: quantity,
      unitPrice: unitPrice,
      note: note,
    );
    await refresh();
    return newQuantity;
  }

  Future<List<StockMovement>> movementsForShoe(int shoeId, {int limit = 100}) =>
      _db.movementsForShoe(shoeId, limit: limit);

  Future<Shoe?> byId(int id) => _db.findById(id);

  /// Recalcule les quantités depuis le journal (outil de vérification).
  Future<int> recalculateQuantities() async {
    final fixed = await _db.recalculateQuantities();
    await refresh();
    return fixed;
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    super.dispose();
  }
}
